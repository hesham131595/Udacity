Cloud front URL : 
https://d26bu7lpje6457.cloudfront.net/

Website endpoint: 

http://my-274118316096-bucket.s3-website-us-east-1.amazonaws.com/

S3 object URL : 
 
https://my-274118316096-bucket.s3.amazonaws.com/index.html